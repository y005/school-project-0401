﻿#include <afxwin.h>

#define IDC_BUTTON0 100
#define IDC_BUTTON1 101
#define IDC_BUTTON2 102
#define IDC_BUTTON3 103
#define IDC_BUTTON4 104
#define IDC_BUTTON5 105
#define IDC_BUTTON6 106
#define IDC_BUTTON7 107
#define IDC_BUTTON8 108

enum { OFF, ON };
// Declare the application class
class CToggleApp : public CWinApp {
public:
	virtual BOOL InitInstance();
};
// Create an instance of the application class
CToggleApp ToggleApp;

// Declare the main window class
class CToggleWindow : public CFrameWnd {
	CButton* button[9];
	int status[9];
	int turn;
	void init();
public:
	CToggleWindow();
	void HandleButton(int _ik);
	afx_msg void HandleButton0();
	afx_msg void HandleButton1();
	afx_msg void HandleButton2();
	afx_msg void HandleButton3();
	afx_msg void HandleButton4();
	afx_msg void HandleButton5();
	afx_msg void HandleButton6();
	afx_msg void HandleButton7();
	afx_msg void HandleButton8();
	DECLARE_MESSAGE_MAP();
	// the InitInstance function is called once
	// when the application first executes
};
BOOL CToggleApp::InitInstance()
{
	m_pMainWnd = new CToggleWindow();
	m_pMainWnd->ShowWindow(m_nCmdShow);
	m_pMainWnd->UpdateWindow();
	return TRUE;
}
// the message map
BEGIN_MESSAGE_MAP(CToggleWindow, CFrameWnd)
	ON_BN_CLICKED(IDC_BUTTON0, HandleButton0)
	ON_BN_CLICKED(IDC_BUTTON1, HandleButton1)
	ON_BN_CLICKED(IDC_BUTTON2, HandleButton2)
	ON_BN_CLICKED(IDC_BUTTON3, HandleButton3)
	ON_BN_CLICKED(IDC_BUTTON4, HandleButton4)
	ON_BN_CLICKED(IDC_BUTTON5, HandleButton5)
	ON_BN_CLICKED(IDC_BUTTON6, HandleButton6)
	ON_BN_CLICKED(IDC_BUTTON7, HandleButton7)
	ON_BN_CLICKED(IDC_BUTTON8, HandleButton8)
END_MESSAGE_MAP()
void CToggleWindow::init()
{
	turn = 0;
	for (int i = 0; i < 9; i++) {
		status[i] = OFF;
	}
}
// the contructor for the window class
CToggleWindow::CToggleWindow()
{
	//Create the window itself
	Create(NULL, _T("Tic-Tac-Toe"),WS_OVERLAPPEDWINDOW,CRect(0, 0, 460, 480));
	init();
	// Create button
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			button[3*i+j] = new CButton();
			button[3*i+j]->Create(_T(""), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, CRect(6+131*j, 6+131*i, 136+131*j, 136+131*i), this, IDC_BUTTON0+3*i+j);
		}
	}
}
void CToggleWindow::HandleButton0() { HandleButton(0); }
void CToggleWindow::HandleButton1() { HandleButton(1); }
void CToggleWindow::HandleButton2() { HandleButton(2); }
void CToggleWindow::HandleButton3() { HandleButton(3); }
void CToggleWindow::HandleButton4() { HandleButton(4); }
void CToggleWindow::HandleButton5() { HandleButton(5); }
void CToggleWindow::HandleButton6() { HandleButton(6); }
void CToggleWindow::HandleButton7() { HandleButton(7); }
void CToggleWindow::HandleButton8() { HandleButton(8); }

// message handler function for number buttons
void CToggleWindow::HandleButton(int _ik)
{
	if (status[_ik] == OFF) {
		if (turn % 2 == 0) {
			button[_ik]->SetWindowText(_T("X"));
			status[_ik] = ON;
			turn = (turn + 1) % 2;
		}
		else {
			button[_ik]->SetWindowText(_T("O"));
			status[_ik] = ON;
			turn = (turn + 1) % 2;
		}
	}
	else{MessageBeep(-1);}
}